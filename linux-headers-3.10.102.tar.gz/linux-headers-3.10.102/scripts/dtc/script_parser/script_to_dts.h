#ifndef _SCRIPT_TO_DTS_H_
#define _SCRIPT_TO_DTS_H_

#include "iniparser.h"
#include "script.h"

int script_parse(const char *script_name);

#endif
