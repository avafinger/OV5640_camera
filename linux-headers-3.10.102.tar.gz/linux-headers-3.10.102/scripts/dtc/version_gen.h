#define DTC_VERSION "DTC 1.2.0-g37c0b6a0"
